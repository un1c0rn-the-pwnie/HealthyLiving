<?php

define('db_db', 'localhost');
define('db_user', 'healthy_living_user');
define('db_pass', 'QsXPl,10_+;!');
define('db_charset', 'utf-8');
define('db_name', 'healthy_living');

?>