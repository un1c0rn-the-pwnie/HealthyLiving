<?php

define( 'PASS_REGEX', '^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$');

define( 'ShowErrors', true );

?>