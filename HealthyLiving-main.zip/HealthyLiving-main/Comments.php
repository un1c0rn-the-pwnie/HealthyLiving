<?php 
    include '.classes/configComments.php';

    require_once '.classes/auth.php';
    require_once 'header.php';

    error_reporting(0); // For not showing any error

    if (isset($_POST['submit'])) { // Check press or not Post Comment Button
        // $name = $_POST['name']; // Get Name from form
        // $email = $_POST['email']; // Get Email from form
        if($logged == true){
            $comment = $_POST['comment']; // Get Comment from form

            $sql = "INSERT INTO comments_system (name, comment)
                    VALUES ('$user', '$comment')";                    // The variabel $user is from header.php 
            $result = mysqli_query($conn, $sql);
        }
        else{
            echo "<script>alert('Λυπάμαι δεν είστε συνδεδεμένος για να κάνετε κάποιο σχόλιο.')</script>";
        }       
    }
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" type="text/css" href="css/Comments.css">
    
</head>
<body>
<div class="wrapper">
    <form action="" method="POST" class="form">
        <div class="input-group textarea">
            <label for="comment">Σχόλια</label>
            <textarea id="comment" name="comment" placeholder="Εισάγετε το σχόλιο σας..." required></textarea>
        </div>
        <div class="input-group">
            <button name="submit" class="btn">Υποβολή Σχολίου</button>
        </div>
    </form>
    <div class="prev-comments">
        <?php 
        $sql = "SELECT * FROM comments_system";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <div class="single-item">
                <h4><?php echo $row['name']; ?></h4>
                <p><?php echo $row['comment']; ?></p>
            </div>
        <?php
            }
        }
        ?>
    </div>
</div>
</body>
</html>