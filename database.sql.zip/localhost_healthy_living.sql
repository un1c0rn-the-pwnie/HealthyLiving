-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 05, 2021 at 02:51 PM
-- Server version: 8.0.25-0ubuntu0.20.04.1
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthy_living`
--
DROP DATABASE IF EXISTS `healthy_living`;
CREATE DATABASE IF NOT EXISTS `healthy_living` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `healthy_living`;


--
-- Users: `healthy_living`
--
CREATE USER IF NOT EXISTS 'healthy_living_user'@'localhost' IDENTIFIED BY 'QsXPl,10_+;!';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE ON healthy_living.* TO 'healthy_living_user'@'localhost';


-- --------------------------------------------------------

--
-- Table structure for table `comments_calculator`
--

CREATE TABLE `comments_calculator` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `comment` mediumtext COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `comments_calculator`
--

INSERT INTO `comments_calculator` (`id`, `name`, `comment`) VALUES
(1, 'Georgos', 'ωωωωωω 23.1 BMI σας έστειλα αδιάβαστους.  ΑΝΤΕ ΓΕΙΑ!'),
(2, 'Themistoklis', 'Μπράβο Γιώργο αυτός είσαι !!');

-- --------------------------------------------------------

--
-- Table structure for table `comments_diet`
--

CREATE TABLE `comments_diet` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `comment` mediumtext COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `comments_diet`
--

INSERT INTO `comments_diet` (`id`, `name`, `comment`) VALUES
(1, 'Georgos', 'Χάρη σε αυτό το άρθρο έχασα 12 κιλά!!!'),
(2, 'admin', 'Εξαιρετικά Γιώργο δεν έχω τι να πώ!');

-- --------------------------------------------------------

--
-- Table structure for table `comments_sport`
--

CREATE TABLE `comments_sport` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `comment` mediumtext COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `comments_sport`
--

INSERT INTO `comments_sport` (`id`, `name`, `comment`) VALUES
(1, 'Themistoklis', 'Έγινα ντούκι , ακολουθήστε το παράδειγμα τους !!!');

-- --------------------------------------------------------

--
-- Table structure for table `reset`
--

CREATE TABLE `reset` (
  `id` int NOT NULL,
  `email` varchar(50) COLLATE latin1_general_cs NOT NULL,
  `code` varchar(32) COLLATE latin1_general_cs NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(20) COLLATE latin1_general_cs NOT NULL,
  `email` varchar(50) COLLATE latin1_general_cs NOT NULL,
  `password` varchar(255) COLLATE latin1_general_cs NOT NULL,
  `salt` varchar(32) COLLATE latin1_general_cs NOT NULL,
  `login_hash` varchar(255) COLLATE latin1_general_cs DEFAULT NULL,
  `rg_date` date NOT NULL,
  `hash` varchar(32) COLLATE latin1_general_cs NOT NULL,
  `active` int NOT NULL DEFAULT '0',
  `isadmin` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `salt`, `login_hash`, `rg_date`, `hash`, `active`, `isadmin`) VALUES
(2, 'Themistoklis', 'themisPetrakos@healthyliving.gr', '30c38cde954bf2ba56f9f3e0500ef3bffbbc54a0b2bc362233dfc437f595ffb289d6458668ff4916760dfb918128cde5c269152c89dbd765c537b6a6b8a4e9b5', 'e586fc3f2e900cb1afea70d64a0b6aff', NULL, '2021-06-05', '1657978a74061a99878188d99ea4aed4', 1, 0),
(3, 'Kostas', 'Kostakis@healthyliving.gr', 'cc9fa5164cb2dcad2b2273e183665bd4756a28d369a563b72f5c3ce8a7d796ee03248f793f6b96e3a578741a607a01fd330ee112c0d449aa04d1fb2c98735e42', 'a7bdec81136a320ce6c737456ff53201', NULL, '2021-06-05', '96427235d53f9f6b499bc6c5e78758c3', 1, 0),
(4, 'Georgos', 'Georgos@healthyliving.gr', 'be1ce50fde46ab9231d2344e86faff779ec54d69cd6034d78d6990cf706c328657a76a189192e29a34af50314aafe4e3a38d6712c8742110147d7a5fca88d509', 'e3ed8ca7063c4ce69f716d34bcd4ab62', NULL, '2021-06-05', '29b52a6c61a1a044fb400931dcab6c1d', 1, 0),
(5, 'admin', 'admin@healthyliving.gr', '507c79a8898a6ee07c1807e59bcbbf6c01f13b185341c03b7cadf7b642fa3a5778d177f5324f2598bff4d5490f86de91e13ae2398e4b48cafbe9952e362f8332', '0c3416d0afb6bf7f34b687e5b60b45fa', NULL, '2021-06-05', 'a1b53459aa79d6d06966d4d31111a797', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments_calculator`
--
ALTER TABLE `comments_calculator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments_diet`
--
ALTER TABLE `comments_diet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments_sport`
--
ALTER TABLE `comments_sport`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reset`
--
ALTER TABLE `reset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments_calculator`
--
ALTER TABLE `comments_calculator`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `comments_diet`
--
ALTER TABLE `comments_diet`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `comments_sport`
--
ALTER TABLE `comments_sport`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reset`
--
ALTER TABLE `reset`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
